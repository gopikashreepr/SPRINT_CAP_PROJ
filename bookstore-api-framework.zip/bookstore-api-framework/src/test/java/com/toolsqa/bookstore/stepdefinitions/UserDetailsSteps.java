package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.User;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.testng.Assert;

public class UserDetailsSteps {

    private final TestContext testContext;

    public UserDetailsSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I fetch the user details using the authorization token")
    public void fetchUserDetailsWithToken() {
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.authenticated(testContext.getToken()))
                        .pathParam("UUID", testContext.getUserId())
                        .when()
                        .get(Endpoints.USER_BY_ID)
        );
    }

    @When("I fetch the user details without an authorization token")
    public void fetchUserDetailsWithoutToken() {
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.unauthenticated())
                        .pathParam("UUID", testContext.getUserId())
                        .when()
                        .get(Endpoints.USER_BY_ID)
        );
    }

    @Then("the user details response status code should be {int}")
    public void verifyUserDetailsStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the user details response userId should match the registered userId")
    public void verifyUserIdMatches() {
        User user = testContext.getLastResponse().as(User.class);
        Assert.assertEquals(user.getUserId(), testContext.getUserId());
    }
}
