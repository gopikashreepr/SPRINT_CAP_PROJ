package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.ReplaceBookRequest;
import com.toolsqa.bookstore.models.User;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.testng.Assert;

public class ReplaceBookSteps {

    private final TestContext testContext;

    public ReplaceBookSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I replace the first book with the second ISBN")
    public void replaceWithSecondIsbn() {
        replaceBook(testContext.getActiveIsbn(), testContext.getSecondaryIsbn());
    }

    @When("I replace the first book with the invalid ISBN {string}")
    public void replaceWithInvalidIsbn(String invalidIsbn) {
        replaceBook(testContext.getActiveIsbn(), invalidIsbn);
    }

    private void replaceBook(String currentIsbn, String newIsbn) {
        ReplaceBookRequest requestBody = new ReplaceBookRequest(testContext.getUserId(), newIsbn);

        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.authenticated(testContext.getToken()))
                        .pathParam("ISBN", currentIsbn)
                        .body(requestBody)
                        .when()
                        .put(Endpoints.BOOKS_BY_ISBN)
        );
    }

    @Then("the replace book response status code should be {int}")
    public void verifyReplaceBookStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the user's collection should contain the second ISBN")
    public void verifyCollectionContainsSecondIsbn() {
        User user = testContext.getLastResponse().as(User.class);
        boolean containsSecondaryIsbn = user.getBooks().stream()
                .anyMatch(book -> book.getIsbn().equals(testContext.getSecondaryIsbn()));
        Assert.assertTrue(containsSecondaryIsbn, "Updated collection did not contain the new ISBN");
    }
}
