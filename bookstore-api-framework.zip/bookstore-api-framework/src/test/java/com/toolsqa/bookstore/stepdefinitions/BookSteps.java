package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.Book;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.testng.Assert;

public class BookSteps {

    private final TestContext testContext;

    public BookSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I fetch the book by that ISBN")
    public void fetchBookByActiveIsbn() {
        fetchBook(testContext.getActiveIsbn());
    }

    @When("I fetch the book using the invalid ISBN {string}")
    public void fetchBookByInvalidIsbn(String invalidIsbn) {
        fetchBook(invalidIsbn);
    }

    private void fetchBook(String isbn) {
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.unauthenticated())
                        .queryParam("ISBN", isbn)
                        .when()
                        .get(Endpoints.BOOK)
        );
    }

    @Then("the book response status code should be {int}")
    public void verifyBookStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the book response ISBN should match the requested ISBN")
    public void verifyBookIsbnMatches() {
        Book book = testContext.getLastResponse().as(Book.class);
        Assert.assertEquals(book.getIsbn(), testContext.getActiveIsbn());
    }
}
