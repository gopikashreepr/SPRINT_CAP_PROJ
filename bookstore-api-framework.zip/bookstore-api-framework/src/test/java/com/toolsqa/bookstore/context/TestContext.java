package com.toolsqa.bookstore.context;

import io.restassured.response.Response;

/**
 * Holds state that needs to flow between step definition classes within the
 * SAME scenario (e.g. the userId/token created in a Background step, the
 * ISBN picked for a Book step, the last HTTP response for assertions).
 *
 * Cucumber creates one instance per scenario via cucumber-picocontainer and
 * injects it into every step-def class constructor, so nothing here is
 * shared *across* scenarios/threads.
 */
public class TestContext {

    private String username;
    private String password;
    private String userId;
    private String token;
    private String activeIsbn;
    private String secondaryIsbn;
    private Response lastResponse;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getActiveIsbn() {
        return activeIsbn;
    }

    public void setActiveIsbn(String activeIsbn) {
        this.activeIsbn = activeIsbn;
    }

    public String getSecondaryIsbn() {
        return secondaryIsbn;
    }

    public void setSecondaryIsbn(String secondaryIsbn) {
        this.secondaryIsbn = secondaryIsbn;
    }

    public Response getLastResponse() {
        return lastResponse;
    }

    public void setLastResponse(Response lastResponse) {
        this.lastResponse = lastResponse;
    }
}
