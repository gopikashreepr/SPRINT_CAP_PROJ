package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.LoginRequest;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.testng.Assert;

public class AccountAuthorizeSteps {

    private final TestContext testContext;

    public AccountAuthorizeSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I check authorization using the registered username and password")
    public void checkAuthorizationWithValidCredentials() {
        checkAuthorization(testContext.getUsername(), testContext.getPassword());
    }

    @When("I check authorization using the registered username and an incorrect password {string}")
    public void checkAuthorizationWithInvalidPassword(String wrongPassword) {
        checkAuthorization(testContext.getUsername(), wrongPassword);
    }

    private void checkAuthorization(String username, String password) {
        LoginRequest requestBody = new LoginRequest(username, password);
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.unauthenticated())
                        .body(requestBody)
                        .when()
                        .post(Endpoints.AUTHORIZED)
        );
    }

    @Then("the authorization response status code should be {int}")
    public void verifyAuthorizationStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the authorization response body should be true")
    public void verifyAuthorizationBodyTrue() {
        Assert.assertTrue(testContext.getLastResponse().as(Boolean.class));
    }

    @And("the authorization response body should be false")
    public void verifyAuthorizationBodyFalse() {
        Assert.assertFalse(testContext.getLastResponse().as(Boolean.class));
    }
}
