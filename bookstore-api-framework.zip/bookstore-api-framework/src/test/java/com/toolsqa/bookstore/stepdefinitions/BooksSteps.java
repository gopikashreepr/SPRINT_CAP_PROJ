package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.AddBooksRequest;
import com.toolsqa.bookstore.models.BooksResponse;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

import java.util.Collections;

import org.testng.Assert;

public class BooksSteps {

    private final TestContext testContext;

    public BooksSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I request the list of all books")
    public void requestAllBooks() {
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.unauthenticated())
                        .when()
                        .get(Endpoints.BOOKS)
        );
    }

    @Then("the books response status code should be {int}")
    public void verifyBooksStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the books response should contain at least one book")
    public void verifyBooksResponseNotEmpty() {
        BooksResponse booksResponse = testContext.getLastResponse().as(BooksResponse.class);
        Assert.assertFalse(booksResponse.getBooks().isEmpty());
    }

    @When("I add that book to the user's collection")
    public void addActiveIsbnToUserCollection() {
        addIsbnToCollection(testContext.getActiveIsbn());
    }

    @When("I add a book with the invalid ISBN {string} to the user's collection")
    public void addInvalidIsbnToUserCollection(String invalidIsbn) {
        addIsbnToCollection(invalidIsbn);
    }

    private void addIsbnToCollection(String isbn) {
        AddBooksRequest.IsbnItem item = new AddBooksRequest.IsbnItem(isbn);
        AddBooksRequest requestBody = new AddBooksRequest(testContext.getUserId(), Collections.singletonList(item));

        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.authenticated(testContext.getToken()))
                        .body(requestBody)
                        .when()
                        .post(Endpoints.BOOKS)
        );
    }

    @Then("the add book response status code should be {int}")
    public void verifyAddBookStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }
}
