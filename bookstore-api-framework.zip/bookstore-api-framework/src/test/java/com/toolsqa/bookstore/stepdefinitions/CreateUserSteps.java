package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.LoginRequest;
import com.toolsqa.bookstore.models.User;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

public class CreateUserSteps {

    private final TestContext testContext;

    public CreateUserSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I create a user with those details")
    public void createUser() {
        Response response = createUserRequest();
        testContext.setLastResponse(response);

        // If creation succeeded, capture the userId and a token so the
        // after-scenario hook can clean this user up from the QA server.
        if (response.getStatusCode() == 201) {
            testContext.setUserId(response.as(User.class).getUserId());
            fetchTokenForCleanup();
        }
    }

    @When("I create a user with those details again")
    public void createUserAgain() {
        testContext.setLastResponse(createUserRequest());
    }

    private Response createUserRequest() {
        LoginRequest requestBody = new LoginRequest(testContext.getUsername(), testContext.getPassword());
        return RestAssured.given()
                .spec(RequestSpecFactory.unauthenticated())
                .body(requestBody)
                .when()
                .post(Endpoints.USER);
    }

    private void fetchTokenForCleanup() {
        LoginRequest requestBody = new LoginRequest(testContext.getUsername(), testContext.getPassword());
        Response tokenResponse = RestAssured.given()
                .spec(RequestSpecFactory.unauthenticated())
                .body(requestBody)
                .when()
                .post(Endpoints.GENERATE_TOKEN);

        if (tokenResponse.getStatusCode() == 200) {
            testContext.setToken(tokenResponse.jsonPath().getString("token"));
        }
    }

    @Then("the create user response status code should be {int}")
    public void verifyCreateUserStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the create user response should contain a generated userId")
    public void verifyGeneratedUserIdPresent() {
        User user = testContext.getLastResponse().as(User.class);
        Assert.assertNotNull(user.getUserId());
        Assert.assertFalse(user.getUserId().isEmpty());
    }

    @And("the create user response username should match the requested username")
    public void verifyResponseUsernameMatches() {
        User user = testContext.getLastResponse().as(User.class);
        Assert.assertEquals(user.getUsername(), testContext.getUsername());
    }
}
