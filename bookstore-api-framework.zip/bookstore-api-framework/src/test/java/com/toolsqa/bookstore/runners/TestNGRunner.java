package com.toolsqa.bookstore.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.toolsqa.bookstore.stepdefinitions", "com.toolsqa.bookstore.hooks"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true,
        publish = false
)
public class TestNGRunner extends AbstractTestNGCucumberTests {

    // Runs scenarios sequentially; flip to true (and set dataprovider thread
    // count in testng.xml) if scenarios are made fully independent later.
    @Override
    public boolean runScenariosInParallel() {
        return false;
    }
}
