package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.LoginRequest;
import com.toolsqa.bookstore.models.TokenResponse;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.testng.Assert;

public class GenerateTokenSteps {

    private final TestContext testContext;

    public GenerateTokenSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @When("I request a token using the registered username and password")
    public void requestTokenWithValidCredentials() {
        requestToken(testContext.getUsername(), testContext.getPassword());
    }

    @When("I request a token using the registered username and an incorrect password {string}")
    public void requestTokenWithInvalidPassword(String wrongPassword) {
        requestToken(testContext.getUsername(), wrongPassword);
    }

    private void requestToken(String username, String password) {
        LoginRequest requestBody = new LoginRequest(username, password);
        testContext.setLastResponse(
                RestAssured.given()
                        .spec(RequestSpecFactory.unauthenticated())
                        .body(requestBody)
                        .when()
                        .post(Endpoints.GENERATE_TOKEN)
        );
    }

    @Then("the token response status code should be {int}")
    public void verifyTokenStatusCode(int expectedStatusCode) {
        Assert.assertEquals(testContext.getLastResponse().getStatusCode(), expectedStatusCode);
    }

    @And("the token response status should be {string}")
    public void verifyTokenResponseStatus(String expectedStatus) {
        TokenResponse tokenResponse = testContext.getLastResponse().as(TokenResponse.class);
        Assert.assertEquals(tokenResponse.getStatus(), expectedStatus);
    }

    @And("a non-empty token should be returned")
    public void verifyNonEmptyTokenReturned() {
        TokenResponse tokenResponse = testContext.getLastResponse().as(TokenResponse.class);
        Assert.assertNotNull(tokenResponse.getToken());
        Assert.assertFalse(tokenResponse.getToken().isEmpty());
    }
}
