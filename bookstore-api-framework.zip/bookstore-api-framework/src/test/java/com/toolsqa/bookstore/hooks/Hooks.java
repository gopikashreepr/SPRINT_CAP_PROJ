package com.toolsqa.bookstore.hooks;

import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.restassured.RestAssured;

public class Hooks {

    private final TestContext testContext;

    public Hooks(TestContext testContext) {
        this.testContext = testContext;
    }

    @Before
    public void beforeScenario(Scenario scenario) {
        System.out.println("Starting scenario: " + scenario.getName());
    }

    /**
     * Best-effort cleanup: if the scenario created a user (and has a token
     * for it), delete that user afterwards so the QA server doesn't
     * accumulate throwaway accounts across runs. Failures here are
     * swallowed on purpose - cleanup should never fail the test itself.
     */
    @After
    public void afterScenario(Scenario scenario) {
        try {
            if (testContext.getUserId() != null && testContext.getToken() != null) {
                RestAssured.given()
                        .spec(RequestSpecFactory.authenticated(testContext.getToken()))
                        .pathParam("UUID", testContext.getUserId())
                        .when()
                        .delete(Endpoints.USER_BY_ID);
            }
        } catch (Exception e) {
            System.out.println("Cleanup skipped: " + e.getMessage());
        }
        System.out.println("Finished scenario: " + scenario.getName() + " -> " + scenario.getStatus());
    }
}
