package com.toolsqa.bookstore.stepdefinitions;

import com.toolsqa.bookstore.config.ConfigManager;
import com.toolsqa.bookstore.constants.Endpoints;
import com.toolsqa.bookstore.context.TestContext;
import com.toolsqa.bookstore.models.AddBooksRequest;
import com.toolsqa.bookstore.models.BooksResponse;
import com.toolsqa.bookstore.models.LoginRequest;
import com.toolsqa.bookstore.models.TokenResponse;
import com.toolsqa.bookstore.models.User;
import com.toolsqa.bookstore.utils.RequestSpecFactory;
import com.toolsqa.bookstore.utils.TestDataUtil;
import io.cucumber.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import java.util.Collections;
import java.util.List;

public class CommonSteps {

    private final TestContext testContext;

    public CommonSteps(TestContext testContext) {
        this.testContext = testContext;
    }

    @Given("a random username and a valid password are prepared")
    public void prepareRandomCredentials() {
        testContext.setUsername(TestDataUtil.randomUsername());
        testContext.setPassword(ConfigManager.getDefaultPassword());
    }

    @Given("a user has already been created with those details")
    public void createUserWithPreparedDetails() {
        registerAndStoreUser(testContext.getUsername(), testContext.getPassword());
    }

    @Given("a new user is registered with a random username and a valid password")
    public void registerNewUser() {
        String username = TestDataUtil.randomUsername();
        String password = ConfigManager.getDefaultPassword();
        registerAndStoreUser(username, password);
    }

    private void registerAndStoreUser(String username, String password) {
        LoginRequest requestBody = new LoginRequest(username, password);

        Response response = RestAssured.given()
                .spec(RequestSpecFactory.unauthenticated())
                .body(requestBody)
                .when()
                .post(Endpoints.USER);

        Assert.assertEquals(response.getStatusCode(), 201,
                "Pre-requisite user creation failed: " + response.getBody().asString());

        User user = response.as(User.class);
        testContext.setUsername(username);
        testContext.setPassword(password);
        testContext.setUserId(user.getUserId());
    }

    @Given("the user generates an authorization token")
    public void generateAuthorizationToken() {
        LoginRequest requestBody = new LoginRequest(testContext.getUsername(), testContext.getPassword());

        Response response = RestAssured.given()
                .spec(RequestSpecFactory.unauthenticated())
                .body(requestBody)
                .when()
                .post(Endpoints.GENERATE_TOKEN);

        Assert.assertEquals(response.getStatusCode(), 200,
                "Pre-requisite token generation failed: " + response.getBody().asString());

        TokenResponse tokenResponse = response.as(TokenResponse.class);
        Assert.assertNotNull(tokenResponse.getToken(), "Token generation did not return a token");
        testContext.setToken(tokenResponse.getToken());
    }

    @Given("a valid ISBN is picked from the available book catalogue")
    public void pickValidIsbn() {
        testContext.setActiveIsbn(fetchCatalogueIsbns().get(0));
    }

    @Given("a second, different valid ISBN is picked from the available book catalogue")
    public void pickSecondValidIsbn() {
        List<String> isbns = fetchCatalogueIsbns();
        String candidate = isbns.stream()
                .filter(isbn -> !isbn.equals(testContext.getActiveIsbn()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Catalogue does not have a second distinct ISBN"));
        testContext.setSecondaryIsbn(candidate);
    }

    @Given("that book is added to the user's collection")
    public void addActiveIsbnToCollection() {
        AddBooksRequest.IsbnItem item = new AddBooksRequest.IsbnItem(testContext.getActiveIsbn());
        AddBooksRequest requestBody = new AddBooksRequest(testContext.getUserId(), Collections.singletonList(item));

        Response response = RestAssured.given()
                .spec(RequestSpecFactory.authenticated(testContext.getToken()))
                .body(requestBody)
                .when()
                .post(Endpoints.BOOKS);

        Assert.assertEquals(response.getStatusCode(), 201,
                "Pre-requisite 'add book to collection' failed: " + response.getBody().asString());
    }

    private List<String> fetchCatalogueIsbns() {
        Response response = RestAssured.given()
                .spec(RequestSpecFactory.unauthenticated())
                .when()
                .get(Endpoints.BOOKS);

        Assert.assertEquals(response.getStatusCode(), 200, "Could not fetch book catalogue");

        BooksResponse booksResponse = response.as(BooksResponse.class);
        Assert.assertFalse(booksResponse.getBooks().isEmpty(), "Book catalogue is empty");

        return booksResponse.getBooks().stream()
                .map(com.toolsqa.bookstore.models.Book::getIsbn)
                .collect(java.util.stream.Collectors.toList());
    }
}
