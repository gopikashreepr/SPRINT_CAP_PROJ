Feature: BookStore Collection Management
  As an API consumer of the ToolsQA BookStore application
  I want to view the full book catalogue and add books to a user's collection
  So that a user's personal library can be built up from available titles

  Background:
    Given a new user is registered with a random username and a valid password
    And the user generates an authorization token

  @positive @bookstore
  Scenario: Successfully fetch the full list of available books
    When I request the list of all books
    Then the books response status code should be 200
    And the books response should contain at least one book

  @positive @bookstore
  Scenario: Successfully add a valid book to the user's collection
    Given a valid ISBN is picked from the available book catalogue
    When I add that book to the user's collection
    Then the add book response status code should be 201

  @negative @bookstore
  Scenario: Fail to add a book with an ISBN that does not exist in the catalogue
    When I add a book with the invalid ISBN "9999999999999" to the user's collection
    Then the add book response status code should be 400
