Feature: Generate Authentication Token
  As an API consumer of the ToolsQA BookStore application
  I want to generate a bearer token for a user
  So that I can access authenticated BookStore endpoints

  Background:
    Given a new user is registered with a random username and a valid password

  @positive @account
  Scenario: Successfully generate a token for valid credentials
    When I request a token using the registered username and password
    Then the token response status code should be 200
    And the token response status should be "Success"
    And a non-empty token should be returned

  @negative @account
  Scenario: Fail to generate a token for invalid credentials
    When I request a token using the registered username and an incorrect password "WrongPass@999"
    Then the token response status code should be 200
    And the token response status should be "Failed"
