Feature: Replace a Book in the User's Collection
  As an API consumer of the ToolsQA BookStore application
  I want to swap one ISBN in a user's collection for another
  So that a user can update their library without a separate delete-then-add step

  Background:
    Given a new user is registered with a random username and a valid password
    And the user generates an authorization token
    And a valid ISBN is picked from the available book catalogue
    And that book is added to the user's collection

  @positive @bookstore
  Scenario: Successfully replace a book already in the collection with a different valid ISBN
    Given a second, different valid ISBN is picked from the available book catalogue
    When I replace the first book with the second ISBN
    Then the replace book response status code should be 200
    And the user's collection should contain the second ISBN

  @negative @bookstore
  Scenario: Fail to replace a book using an ISBN that does not exist
    When I replace the first book with the invalid ISBN "9999999999999"
    Then the replace book response status code should be 400
