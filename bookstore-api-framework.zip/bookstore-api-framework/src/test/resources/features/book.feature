Feature: Get Book By ISBN
  As an API consumer of the ToolsQA BookStore application
  I want to fetch details for a single book by its ISBN
  So that I can display or verify that book's information

  @positive @bookstore
  Scenario: Successfully fetch a book using a valid ISBN
    Given a valid ISBN is picked from the available book catalogue
    When I fetch the book by that ISBN
    Then the book response status code should be 200
    And the book response ISBN should match the requested ISBN

  @negative @bookstore
  Scenario: Fail to fetch a book using an ISBN that does not exist
    When I fetch the book using the invalid ISBN "9999999999999"
    Then the book response status code should be 400
