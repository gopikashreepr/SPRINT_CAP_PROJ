Feature: Get User Details
  As an API consumer of the ToolsQA BookStore application
  I want to fetch the details of a user by their userId
  So that I can verify the account's userId, username, and book collection

  Background:
    Given a new user is registered with a random username and a valid password
    And the user generates an authorization token

  @positive @account
  Scenario: Successfully fetch user details using a valid token
    When I fetch the user details using the authorization token
    Then the user details response status code should be 200
    And the user details response userId should match the registered userId

  @negative @account
  Scenario: Fail to fetch user details without an authorization token
    When I fetch the user details without an authorization token
    Then the user details response status code should be 401
