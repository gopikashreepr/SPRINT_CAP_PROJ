Feature: Account Authorization
  As an API consumer of the ToolsQA BookStore application
  I want to check whether a given username/password pair is authorized
  So that I can confirm a user's credentials before performing further actions

  Background:
    Given a new user is registered with a random username and a valid password

  @positive @account
  Scenario: Verify a registered user is authorized with correct credentials
    When I check authorization using the registered username and password
    Then the authorization response status code should be 200
    And the authorization response body should be true

  @negative @account
  Scenario: Verify authorization fails for an incorrect password
    When I check authorization using the registered username and an incorrect password "WrongPass@999"
    Then the authorization response status code should be 200
    And the authorization response body should be false
