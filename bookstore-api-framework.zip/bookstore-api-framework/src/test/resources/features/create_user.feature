Feature: Create User Account
  As an API consumer of the ToolsQA BookStore application
  I want to create new user accounts
  So that I can perform authenticated BookStore operations on their behalf

  @positive @account
  Scenario: Successfully create a new user with valid details
    Given a random username and a valid password are prepared
    When I create a user with those details
    Then the create user response status code should be 201
    And the create user response should contain a generated userId
    And the create user response username should match the requested username

  @negative @account
  Scenario: Fail to create a user with a username that already exists
    Given a random username and a valid password are prepared
    And a user has already been created with those details
    When I create a user with those details again
    Then the create user response status code should be 406
