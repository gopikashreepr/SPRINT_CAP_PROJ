package com.toolsqa.bookstore.utils;

import java.util.UUID;

/**
 * Generates unique test data per scenario run so tests can be re-executed
 * without colliding with a previously created user (the API rejects
 * duplicate usernames with a 406).
 */
public final class TestDataUtil {

    private TestDataUtil() {
    }

    public static String randomUsername() {
        return "gops_qa_" + UUID.randomUUID().toString().substring(0, 8);
    }
}
