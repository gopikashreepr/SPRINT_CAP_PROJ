package com.toolsqa.bookstore.models;

/**
 * Maps to the LoginViewModel schema, used by Authorized, GenerateToken and
 * User (create) requests.
 */
public class LoginRequest {

    private String userName;
    private String password;

    public LoginRequest() {
    }

    public LoginRequest(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
