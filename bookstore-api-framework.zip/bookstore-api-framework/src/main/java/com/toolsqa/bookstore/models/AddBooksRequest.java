package com.toolsqa.bookstore.models;

import java.util.List;

/**
 * Maps to the AddListOfBooks schema.
 */
public class AddBooksRequest {

    private String userId;
    private List<IsbnItem> collectionOfIsbns;

    public AddBooksRequest() {
    }

    public AddBooksRequest(String userId, List<IsbnItem> collectionOfIsbns) {
        this.userId = userId;
        this.collectionOfIsbns = collectionOfIsbns;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<IsbnItem> getCollectionOfIsbns() {
        return collectionOfIsbns;
    }

    public void setCollectionOfIsbns(List<IsbnItem> collectionOfIsbns) {
        this.collectionOfIsbns = collectionOfIsbns;
    }

    /**
     * Nested {"isbn": "..."} entry required by the collectionOfIsbns array.
     */
    public static class IsbnItem {
        private String isbn;

        public IsbnItem() {
        }

        public IsbnItem(String isbn) {
            this.isbn = isbn;
        }

        public String getIsbn() {
            return isbn;
        }

        public void setIsbn(String isbn) {
            this.isbn = isbn;
        }
    }
}
