package com.toolsqa.bookstore.utils;

import com.toolsqa.bookstore.config.ConfigManager;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

/**
 * Builds a fresh RestAssured RequestSpecification per call so that scenarios
 * running in the same JVM never leak headers/auth from one request into the
 * next.
 */
public final class RequestSpecFactory {

    private RequestSpecFactory() {
    }

    /** Unauthenticated spec: used for Authorized, GenerateToken, create User, GET Books/Book. */
    public static RequestSpecification unauthenticated() {
        return new RequestSpecBuilder()
                .setBaseUri(ConfigManager.getBaseUri())
                .setContentType(ContentType.JSON)
                .log(LogDetail.METHOD)
                .build();
    }

    /** Authenticated spec: attaches the Bearer token generated for the current test user. */
    public static RequestSpecification authenticated(String token) {
        return new RequestSpecBuilder()
                .setBaseUri(ConfigManager.getBaseUri())
                .setContentType(ContentType.JSON)
                .addHeader("Authorization", "Bearer " + token)
                .log(LogDetail.METHOD)
                .build();
    }
}
