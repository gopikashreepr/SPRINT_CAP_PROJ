package com.toolsqa.bookstore.constants;

/**
 * Centralised endpoint paths, sourced from the BookStore OpenAPI spec.
 * Keeping these in one place means a path change only needs one edit.
 */
public final class Endpoints {

    private Endpoints() {
    }

    // Account
    public static final String AUTHORIZED = "/Account/v1/Authorized";
    public static final String GENERATE_TOKEN = "/Account/v1/GenerateToken";
    public static final String USER = "/Account/v1/User";
    public static final String USER_BY_ID = "/Account/v1/User/{UUID}";

    // BookStore
    public static final String BOOKS = "/BookStore/v1/Books";
    public static final String BOOK = "/BookStore/v1/Book";
    public static final String BOOKS_BY_ISBN = "/BookStore/v1/Books/{ISBN}";
}
