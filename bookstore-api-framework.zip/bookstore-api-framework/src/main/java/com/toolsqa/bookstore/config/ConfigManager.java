package com.toolsqa.bookstore.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Loads and exposes values from config.properties (src/test/resources).
 * Implemented as a simple eager-loaded singleton so every layer of the
 * framework (main + test) can read configuration the same way.
 */
public final class ConfigManager {

    private static final Properties PROPERTIES = new Properties();

    static {
        try (InputStream input = ConfigManager.class.getClassLoader()
                .getResourceAsStream("config.properties")) {
            if (input == null) {
                throw new RuntimeException("Unable to find config.properties on the classpath");
            }
            PROPERTIES.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config.properties", e);
        }
    }

    private ConfigManager() {
    }

    public static String get(String key) {
        String value = PROPERTIES.getProperty(key);
        if (value == null) {
            throw new RuntimeException("Missing property in config.properties: " + key);
        }
        return value;
    }

    public static String getBaseUri() {
        return get("base.uri");
    }

    public static String getDefaultPassword() {
        return get("default.password");
    }
}
