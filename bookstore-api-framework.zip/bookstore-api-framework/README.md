# ToolsQA BookStore API Automation Framework

RestAssured + Cucumber (BDD) + TestNG framework for `https://bookstore.toolsqa.com`,
built from the provided OpenAPI spec. Produces both the native Cucumber HTML/JSON
report and an Extent (Spark) report on every run.

## Stack
- Java 11, Maven
- REST Assured 5.4.0
- Cucumber 7.15.0 (`cucumber-java`, `cucumber-testng`, `cucumber-picocontainer` for DI)
- TestNG 7.9.0 (runs the Cucumber suite via `AbstractTestNGCucumberTests`)
- ExtentReports 5.1.1 + `extentreports-cucumber6-adapter` (auto-generates Extent from Cucumber events)
- Jackson (POJO request/response mapping)

## Project layout
```
src/main/java/com/toolsqa/bookstore/
  config/        ConfigManager        -> reads config.properties
  constants/     Endpoints            -> all API paths in one place
  models/        LoginRequest, TokenResponse, ErrorResponse, Book, BooksResponse,
                 User, AddBooksRequest, DeleteBookRequest, ReplaceBookRequest
  utils/         RequestSpecFactory   -> auth'd / unauth'd RestAssured specs
                 TestDataUtil         -> random username generator

src/test/java/com/toolsqa/bookstore/
  context/       TestContext          -> per-scenario state shared via PicoContainer DI
  hooks/         Hooks                -> logging + best-effort test-user cleanup
  stepdefinitions/
    CommonSteps            -> shared Given steps (register user, get token, pick ISBN...)
    AccountAuthorizeSteps  -> POST /Account/v1/Authorized
    GenerateTokenSteps     -> POST /Account/v1/GenerateToken
    CreateUserSteps        -> POST /Account/v1/User
    UserDetailsSteps       -> GET  /Account/v1/User/{UUID}
    BooksSteps             -> GET/POST /BookStore/v1/Books
    BookSteps              -> GET  /BookStore/v1/Book
    ReplaceBookSteps       -> PUT  /BookStore/v1/Books/{ISBN}
  runners/       TestNGRunner         -> @CucumberOptions + Extent adapter plugin

src/test/resources/
  features/      7 feature files, one per endpoint (15 scenarios total, each file has >=1 @negative)
  config.properties, extent-config.xml
```

## Feature -> scenario coverage (15 scenarios / 7 files)
| Feature file | Endpoint | Scenarios |
|---|---|---|
| account_authorize.feature | POST /Account/v1/Authorized | 1 positive, 1 negative |
| generate_token.feature | POST /Account/v1/GenerateToken | 1 positive, 1 negative |
| create_user.feature | POST /Account/v1/User | 1 positive, 1 negative (duplicate username) |
| user_details.feature | GET /Account/v1/User/{UUID} | 1 positive, 1 negative (no token -> 401) |
| books.feature | GET/POST /BookStore/v1/Books | 2 positive, 1 negative (invalid ISBN -> 400) |
| book.feature | GET /BookStore/v1/Book | 1 positive, 1 negative (invalid ISBN -> 400) |
| replace_book.feature | PUT /BookStore/v1/Books/{ISBN} | 1 positive, 1 negative (invalid ISBN -> 400) |

Every scenario creates its own randomly-named user (or picks live ISBNs from
`GET /BookStore/v1/Books`), so the suite is idempotent and safe to re-run.
The `Hooks` class deletes each scenario's test user afterwards on a best-effort basis.

## Running

```bash
mvn clean test
```

Run only negative scenarios:
```bash
mvn clean test -Dcucumber.filter.tags="@negative"
```

Run only one area (e.g. BookStore endpoints):
```bash
mvn clean test -Dcucumber.filter.tags="@bookstore"
```

## Reports
- **Cucumber HTML/JSON**: `target/cucumber-reports/cucumber.html` / `cucumber.json`
- **Extent (Spark) report**: `test-output/SparkReport/Spark.html`
- Console output also shows `pretty` step-by-step Gherkin execution.

## Notes / assumptions
- `default.password` in `config.properties` (`Test@1234`) satisfies the ToolsQA
  password policy (min 8 chars, upper+lower+digit+special char).
- "Invalid ISBN" negative scenarios use the literal `9999999999999`, which does
  not exist in the BookStore catalogue.
- Scenario count/negative-case split above is my interpretation of "4 scenarios,
  at least 1 negative, 10-15 test cases total, all endpoints in separate feature
  files" — let me know if you'd rather have exactly 4 scenarios per file instead.
